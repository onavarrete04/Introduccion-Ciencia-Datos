def init(graphql, **_):
    print(f"soy modulo uno {graphql}")
