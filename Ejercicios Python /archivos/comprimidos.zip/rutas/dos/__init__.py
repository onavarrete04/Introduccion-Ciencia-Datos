def init(db, api, **_):
    print(f"soy modulo dos {db} - {api}")
