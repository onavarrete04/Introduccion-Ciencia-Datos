
if __name__ != "__main__":

    from ...gestion.crud import guardar

    def pagar_impuestos():
        print("Pagando mis impuestos")
        guardar()


if __name__ == "__main__":
    print("tarea de mantenimiento")
