"""Modulos"""


def guardar():
    print("Guardando")


def pagar_impuestos():
    print("pagando impuestos")
