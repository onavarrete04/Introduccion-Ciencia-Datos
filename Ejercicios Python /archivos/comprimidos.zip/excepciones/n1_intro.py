"""Capturan excepciones"""

try:
    n1 = int(input("ingrese primer numero "))
except:
    print("Ocurrio un error")
