"""  s """
mensaje: str = "Hola mundo"

# Clases: molde
# objeto: producto

# clase: humano
# objeto: persona 1 y otras
