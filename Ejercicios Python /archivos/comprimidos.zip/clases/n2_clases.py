"""Class"""


class Perro:
    """Primera clases"""

    def habla(self):
        """Ladra"""
        print("Guau")


drako = Perro()
drako.habla()

print(isinstance(drako, Perro))
# indica si el objeto drako es de Perro
