"""Listas"""

letras: list = ["a", "b", "c"]

ceros: list = [0, 1] * 10
print(ceros)

alfanumerico: list = letras + ceros
print(alfanumerico)

rango: list = list(range(10))
print(rango)

chars = list("hola mundo")
print(chars)
