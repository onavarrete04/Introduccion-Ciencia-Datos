"""manipulacion"""

mascotas = ["Wolfgang", "Pelusa", "Pulga", "Copito"]

print(mascotas[0])

mascotas[0] = "Bicho"

print(mascotas[0])

print(mascotas[1::2])  # accede solo a pares


numeros: list = list(range(21))
print(numeros[1::2])
