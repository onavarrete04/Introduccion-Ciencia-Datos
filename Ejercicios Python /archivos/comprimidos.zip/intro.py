""" Ejercicio python"""
import math

print("hola")

print("hola")
chanchito: str = "pepino"
chanchito: list = [1, 2, 3, 4, 5]
print(chanchito)

math.ceil(1.3)  # devuelve el numero más cercano
print(math.pow(1.5, 3))
print(abs(-77))  # devuelve el valor absoluto
print(abs(77))

print(math.ceil(1.1))  # devuelve el más cercano arriba
print(math.floor(1.9999))  # cercano hacia abajo
print(math.isnan(4))  # si es numero o no
print(math.sqrt(25))  # raiz cuadrado
print(math.pow(2, 3))  # eleva al cuadrado
