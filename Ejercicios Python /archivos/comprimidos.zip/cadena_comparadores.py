"""cadena-comparadores """

edad: int = 25

if 15 <= edad <= 65:
    print("puedes entrar a la piscina")
